public class Dictionary<K,V> {
    // Declare class attributes
    int capacity;
    KeyValuePair<K,V>[] table;
    private final KeyValuePair<K,V> DELETED;

    public Dictionary(){
        // Initialize class attributes
        capacity = 7;
        table = new KeyValuePair[capacity];
        DELETED = new KeyValuePair<K,V>(null, null);
    }

    /**
     * Adds the specified key and value into the dictaonary.
     * @param key
     * @param value
     */
    public void insert(K key, V value){
        int index = hash(key);
        while(table[index] != null || table[index] == DELETED) {
            index++;
            index %= capacity;
        }
        table[index] = new KeyValuePair<K,V>(key, value);
    }

    /**
     * Searches for the value that belongs to the given key. Returns null if not found.
     * @param key
     * @return
     */
    public V search(K key){
        int index = hash(key);
        int start = index;
        while (table[index].getKey() != key){
            index++;
            index %= capacity;
            while (table[index] == null) index++;
            if (index == start) return null;
        }
        return table[index].getValue();
    }

    /**
     * Deletes the key and value from the dictionary.
     * @param key
     */
    public void delete(K key){
        if (search(key) != null){
            int index = hash(key);
            while (table[index].getKey() != key){
                index++;
                index %=capacity;
                while (table[index] == null) index++;
            }
            table[index] = DELETED;
        }
    }

    /**
     * Map intigers of a large range into a smaller range.
     * @param key
     * @param value
     */
    private int hash(K key){
        return key.hashCode() % capacity;
        
    }    
}
